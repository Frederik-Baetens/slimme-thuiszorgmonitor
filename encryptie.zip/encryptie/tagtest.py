import Encryptie

lst = [46, 50, 47, 46, 50, 46, 46, 50, 45, 45, 50, 47, 66, 65, 64, 64]
print ('Encryptie1:' ,Encryptie.Vercijfering(1185,lst))
print ('Encryptie2:' ,Encryptie.Vercijfering(1185,lst))
print ('Encryptie3:' ,Encryptie.Vercijfering(1185,lst))

